<?php
/**
 * Categories link shortcode
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

vc_map(
    array(
        'name'        => esc_html__( 'Thim Categories Link', 'hotel-wp' ),
        'base'        => 'thim-categories-link',
        'class'       => '',
        'category'    => esc_html__( 'Thim Shortcodes', 'hotel-wp' ),
        'description' => esc_html__( 'Display Categories link.', 'hotel-wp' ),
        'params'      => array(
            // Background image
            array(
                'type'        => 'attach_image',
                'heading'     => esc_html__( 'Background Image', 'hotel-wp' ),
                'param_name'  => 'background_image',
                'admin_label' => true,
                'value'       => '',
            ),

            // Title
            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Categories Title', 'hotel-wp' ),
                'admin_label' => true,
                'param_name'  => 'categories_title',
                'value'       => '',
                'description' => esc_html__( 'Categories Title.', 'hotel-wp' ),
            ),

            //Use custom or default title?
            array(
                'type'        => 'dropdown',
                'admin_label' => true,
                'heading'     => esc_html__( 'Use custom or default categories title?', 'hotel-wp' ),
                'param_name'  => 'title_custom',
                'value'       => array(
                    esc_html__( 'Default', 'hotel-wp' ) => '',
                    esc_html__( 'Custom', 'hotel-wp' )  => 'custom',
                ),
                'description' => esc_html__( 'If you select default you will use default title which customized in typography.', 'hotel-wp' )
            ),

            //Title color
            array(
                'type'        => 'colorpicker',
                'admin_label' => true,
                'heading'     => esc_html__( 'Categories title color ', 'hotel-wp' ),
                'param_name'  => 'title_color',
                'value'       => '#E7AD44',
                'description' => esc_html__( 'Select the categories title color.', 'hotel-wp' ),
                'dependency'  => array(
                    'element' => 'title_custom',
                    'value'   => 'custom',
                ),
            ),
            //Title size
            array(
                'type'        => 'number',
                'admin_label' => true,
                'heading'     => esc_html__( 'Categories title size ', 'hotel-wp' ),
                'param_name'  => 'title_size',
                'min'         => 0,
                'value'       => '24',
                'suffix'      => 'px',
                'description' => esc_html__( 'Select the categories title size.', 'hotel-wp' ),
                'dependency'  => array(
                    'element' => 'title_custom',
                    'value'   => 'custom',
                ),
            ),
            //Title weight
            array(
                'type'        => 'dropdown',
                'admin_label' => true,
                'heading'     => esc_html__( 'Categories title font weight ', 'hotel-wp' ),
                'param_name'  => 'title_weight',
                'value'       => array(
                    esc_html__( 'Choose the title font weight', 'hotel-wp' ) => '',
                    esc_html__( 'Normal', 'hotel-wp' )                       => 'normal',
                    esc_html__( 'Bold', 'hotel-wp' )                         => 'bold',
                    esc_html__( 'Bolder', 'hotel-wp' )                       => 'bolder',
                    esc_html__( 'Lighter', 'hotel-wp' )                      => 'lighter',
                ),
                'description' => esc_html__( 'Select the categories title font weight.', 'hotel-wp' ),
                'dependency'  => array(
                    'element' => 'title_custom',
                    'value'   => 'custom',
                ),
            ),
            //Title style
            array(
                'type'        => 'dropdown',
                'admin_label' => true,
                'heading'     => esc_html__( 'Categories title font style ', 'hotel-wp' ),
                'param_name'  => 'title_style',
                'value'       => array(
                    esc_html__( 'Choose the title font style', 'hotel-wp' ) => '',
                    esc_html__( 'Italic', 'hotel-wp' )                      => 'italic',
                    esc_html__( 'Oblique', 'hotel-wp' )                     => 'oblique',
                    esc_html__( 'Initial', 'hotel-wp' )                     => 'initial',
                    esc_html__( 'Inherit', 'hotel-wp' )                     => 'inherit',
                ),
                'description' => esc_html__( 'Select the categories title font style.', 'hotel-wp' ),
                'dependency'  => array(
                    'element' => 'title_custom',
                    'value'   => 'custom',
                ),
            ),

            // Title Alignment
            array(
                'type'        => 'dropdown',
                'admin_label' => true,
                'heading'     => esc_html__( 'Categories title alignment', 'hotel-wp' ),
                'param_name'  => 'title_alignment',
                'value'       => array(
                    'Choose the text alignment'         => '',
                    esc_html__( 'Title at center bottom', 'hotel-wp' )   => 'center-bottom',
                    esc_html__( 'Title at center center', 'hotel-wp' ) => 'center-center',
                    esc_html__( 'Title at right', 'hotel-wp' )  => 'right',
                ),
                'dependency'  => array(
                    'element' => 'title_custom',
                    'value'   => 'custom',
                ),
            ),

            //Display line?
            array(
                'type'        => 'checkbox',
                'admin_label' => true,
                'heading'     => esc_html__( 'Show line?', 'hotel-wp' ),
                'param_name'  => 'show_line',
                'description' => esc_html__( 'Tick it to show line in bottom of title.', 'hotel-wp' ),
                'dependency'  => array(
                    'element' => 'title_custom',
                    'value'   => 'custom',
                ),
            ),

            // Link
            array(
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Categories Link', 'hotel-wp' ),
                'admin_label' => true,
                'param_name'  => 'categories_link',
                'value'       => '',
                'description' => esc_html__( 'Categories Link.', 'hotel-wp' ),
            ),

            //Animation
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__( "Animation", "hotel-wp" ),
                "param_name"  => "css_animation",
                "admin_label" => true,
                "value"       => array(
                    esc_html__( "No", "hotel-wp" )                 => '',
                    esc_html__( "Top to bottom", "hotel-wp" )      => "top-to-bottom",
                    esc_html__( "Bottom to top", "hotel-wp" )      => "bottom-to-top",
                    esc_html__( "Left to right", "hotel-wp" )      => "left-to-right",
                    esc_html__( "Right to left", "hotel-wp" )      => "right-to-left",
                    esc_html__( "Appear from center", "hotel-wp" ) => "appear"
                ),
                "description" => esc_html__( "Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", "hotel-wp" )
            ),
            // Extra class
            array(
                'type'        => 'textfield',
                'admin_label' => true,
                'heading'     => esc_html__( 'Extra class', 'hotel-wp' ),
                'param_name'  => 'el_class',
                'value'       => '',
                'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'hotel-wp' ),
            ),
        )
    )

);

/**
 * include template
 */
include_once 'tpl/default.php';