<?php
/**
 * Shortcode Categories link
 *
 * @param $atts
 *
 * @return string
 */

add_shortcode( 'thim-categories-link', 'thim_shortcode_categories_link' );
function thim_shortcode_categories_link ( $atts ) {
    $categories_link = shortcode_atts( array(
        'background_image'  => '',
        'categories_title'	=> '',
        'categories_link' 	=> '',
        'title_custom'      => '',
        'title_color'       => '',
        'title_size'        => '',
        'title_weight'      => '',
        'title_style'       => '',
        'title_alignment'   => '',
        'show_line'         => '',
        'css_animation'     => '',
        'el_class'          => '',
    ), $atts );

    $css_animation = thim_getCSSAnimation( $categories_link['css_animation'] );
    $img_src = $image = '';

    // Images
    $background_image = $categories_link['background_image'];
    if ( $background_image ) {
        $src         = wp_get_attachment_image_src( $background_image, 'full' );
        $img_src     = $src['0'];
    }

    // Link
    $link = '';
    if ( $categories_link['categories_link'] ) {
        $link .= '<a class="categories-link" href="' . esc_url( $categories_link['categories_link'] ) . '"></a>';
    }

    // Turn off line
    if ( $categories_link['show_line'] == true ) {
        $line = 'has-line';
    } else { $line = ''; }

    // Heading primary inline style
    $title_css = '';
    if ($categories_link['title_color']) {
        $title_css .= 'color: '. $categories_link['title_color'] .';';
    }
    if ($categories_link['title_size']) {
        $title_css .= 'font-size: '. $categories_link['title_size'] .'px;';
    }
    if ($categories_link['title_weight']) {
        $title_css .= 'font-weight: '. $categories_link['title_weight'] .';';
    }
    if ($categories_link['title_style']) {
        $title_css .= 'font-style: '. $categories_link['title_style'] .';';
    }
    if ( $title_css ) {
        $title_css = 'style="'. $title_css .'"';
    }

    $html = '
        <div class="thim-sc-categories-link ' . ent2ncr( $css_animation ) . ' ' . esc_attr( $categories_link['el_class'] ) . '">
            <div class="content">
                <img src="' . esc_url( $img_src ) . '" alt="' . get_the_title( $background_image ) . '" />
                <h4 class="categories-title ' . esc_attr( $categories_link['title_alignment'] ) . ' '. esc_attr( $line ) .'" ' . ent2ncr( $title_css ) . '>'. $categories_link['categories_title'] .'</h4>
                '. $link .'
            </div>
        </div>
    ';

    return ent2ncr( $html );
}