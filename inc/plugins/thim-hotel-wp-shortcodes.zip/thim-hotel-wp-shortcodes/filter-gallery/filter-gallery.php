<?php
/**
 * Shortcode Filter gallery
 */

vc_map(
    array(
        'name'        => esc_html__( 'Thim Filter Gallery', 'hotel-wp' ),
        'base'        => 'thim-filter-gallery',
        'class'       => '',
        'category'    => esc_html__( 'Thim Shortcodes', 'hotel-wp' ),
        'description' => esc_html__( 'Display Gallery.', 'hotel-wp' ),
        'params'      => array(
            // Gallery grid columns
            array(
                'type'        => 'number',
                'admin_label' => true,
                'heading'     => esc_html__( 'Number of columns', 'hotel-wp' ),
                'param_name'  => 'cell',
                'min'         => 1,
                'max'         => 4,
                'value'       => 3,
                'description' => esc_html__( 'Gallery shortcode supports maximum 4 columns.', 'hotel-wp' ),
            ),
            
            //Animation
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__( "Animation", "hotel-wp" ),
                "param_name"  => "css_animation",
                "admin_label" => true,
                "value"       => array(
                    esc_html__( "No", "hotel-wp" )                 => '',
                    esc_html__( "Top to bottom", "hotel-wp" )      => "top-to-bottom",
                    esc_html__( "Bottom to top", "hotel-wp" )      => "bottom-to-top",
                    esc_html__( "Left to right", "hotel-wp" )      => "left-to-right",
                    esc_html__( "Right to left", "hotel-wp" )      => "right-to-left",
                    esc_html__( "Appear from center", "hotel-wp" ) => "appear"
                ),
                "description" => esc_html__( "Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", "hotel-wp" )
            ),
            // Extra class
            array(
                'type'        => 'textfield',
                'admin_label' => true,
                'heading'     => esc_html__( 'Extra class', 'hotel-wp' ),
                'param_name'  => 'el_class',
                'value'       => '',
                'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'hotel-wp' ),
            ),
        )
    )
);

/**
 * include template
 */
include_once 'tpl/default.php';