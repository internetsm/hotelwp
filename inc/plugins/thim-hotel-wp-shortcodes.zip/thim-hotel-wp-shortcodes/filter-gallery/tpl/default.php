<?php
/**
 * Shortcode filter gallery
 *
 * @param $atts
 *
 * @return string
 */

add_shortcode( 'thim-filter-gallery', 'thim_shortcode_filter_gallery' );
function thim_shortcode_filter_gallery ( $atts ) {
    $gallery = shortcode_atts( array(
        'cell'              => 6,
        'css_animation'     => '',
        'el_class'          => '',
    ), $atts );

    $css_animation = thim_getCSSAnimation( $gallery['css_animation'] );
    // Get grid
    $cell       = floor( 12 / $gallery['cell'] );
    $grid_class = 'col-sm-' . $cell . '';

    // Get images amount
    $args = array(
        'post_type' => 'post',
        'tax_query' => array(
            array(
                'taxonomy' => 'post_format',
                'field'    => 'slug',
                'terms'    => array( 'post-format-gallery' ),
            ),
        ),
    );

    $the_query = new WP_Query( $args );

    // html output
    $html = $image_html = '';
    $html .= '<div class="thim-sc-filter-gallery ' . ent2ncr( $css_animation ) . ' ' . esc_attr( $gallery['el_class'] ) . '">';

    if ( $the_query->have_posts() ) {
        $html .='<div class="wrapper-filter-controls">';
            $html .='<div class="filter-controls">';
                $html .= '<h5><a class="filter all active" data-filter="*" href="javascript:;">'. esc_html__('All', 'hotel-wp') .'</a></h5>';
                while ( $the_query->have_posts() ) : $the_query->the_post();
                    $html .='<h5><a class="filter" href="javascript:;" data-filter=".filter-gallery-' . get_the_ID() . '">' . get_the_title(get_the_ID()) . '</a></h5>';
                endwhile;
            $html .='</div>';
        $html .='</div>';


        $html .= ' <div class="wrapper-gallery-filter grid row" itemscope itemtype="http://schema.org/ItemList">';
            while ( $the_query->have_posts() ) : $the_query->the_post();
                $images = thim_meta( 'thim_gallery', "type=image&single=false&size=full" );
                if ( empty( $images ) ) {
                    break;
                }
                foreach ( $images as $image ) {
                    $data        = @getimagesize( $image['url'] );
                    $width_data  = $data[0];
                    $height_data = $data[1];
                    if ( !( $width_data > 570 ) && !( $height_data > 500 ) ) {
                        $html .= '<div class="item-photo '. $grid_class .' filter-gallery-' . get_the_ID() . '"><div class="inner magnific" data-magnific-group="gallery" ><a class="magnific-link" href="' . $image['url'] . '"><img src="' . $image['url'] . '" alt= "' . get_the_title() . '" title = "' . get_the_title() . '" /></a></div></div>';
                    } else {
                        $crop       = ( $height_data < 500 ) ? false : true;
                        $image_crop = thim_aq_resize( $image['url'], 570, 500, $crop );
                        $html .= '<div class="item-photo '. $grid_class .' filter-gallery-' . get_the_ID() . '"><div class="inner magnific" data-magnific-group="gallery" ><a  class="magnific-link" href="' . $image['url'] . '"><img src="' . $image_crop . '" alt= "' . get_the_title() . '" title = "' . get_the_title() . '" /></a></div></div>';
                    }
                }
            endwhile;
        $html .= '</div>';
    }

    $html .= '</div>';

    wp_reset_postdata();

    return $html;
};