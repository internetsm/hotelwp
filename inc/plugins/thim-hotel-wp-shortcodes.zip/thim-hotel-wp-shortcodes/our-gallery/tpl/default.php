<?php

$title     = $params['title'];
$sub_title = $params['sub-title'];

$limit = $params['limit'];
$items = $params['item-visible'];

$image_size = $params['image-size'];

$nav  = empty( $params['show-navigation'] ) ? 'false' : 'true';
$dots = empty( $params['show-dots'] ) ? 'false' : 'true';

$auto = $params['auto'];


if ( ! empty( $title ) ) {
	?>
    <div class="thim-our-gallery-heading">
        <div class="thim-sc-heading">
            <div class="article_heading">
                <h3 class="title"><?php echo $title; ?></h3>
				<?php
				if ( ! empty( $sub_title ) ) {
					?>
                    <div class="heading-des"><?php echo $sub_title; ?></div>
					<?php
				}
				?>
            </div>
        </div>
    </div>
	<?php
}

$available_imgae_sizes = get_intermediate_image_sizes();
preg_match_all( '!\d+!', $image_size, $result );
if ( in_array( $image_size, $available_imgae_sizes ) ) {
    ?>
    <div class="thim-our-gallery owl-carousel owl-theme" data-visible="<?php echo esc_attr( $items ); ?>"
         data-nav="<?php echo esc_attr( $nav ); ?>" data-dots="<?php echo esc_attr( $dots ); ?>"
         data-auto="<?php echo esc_attr( $auto ); ?>">
		<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); ?>

			<?php
			$images = thim_meta( 'thim_gallery', "type=image&single=false&size=thumbnail" );
			$photos = sizeof( $images );

			$src = get_the_post_thumbnail_url( get_the_ID(), $image_size );

			?>

            <div class="item">
                <a class="image" href="<?php echo esc_attr( get_permalink() ); ?>"
                   data-post="<?php echo esc_attr( get_the_ID() ); ?>" data-count="<?php echo esc_attr( $photos ); ?>">
                    <img src="<?php echo esc_attr( $src ); ?>">
                </a>
                <div class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
                <div class="count">
					<?php

					if ( $photos <= 1 ) {
						echo $photos . ' photo';
					} else {
						echo $photos . ' photos';
					}
					?>
                </div>
            </div>

		<?php endwhile;
			wp_reset_postdata();
		endif; ?>
    </div>
    <?php
}else{
    ?>
    <div class="thim-our-gallery owl-carousel owl-theme" data-visible="<?php echo esc_attr( $items ); ?>"
         data-nav="<?php echo esc_attr( $nav ); ?>" data-dots="<?php echo esc_attr( $dots ); ?>"
         data-auto="<?php echo esc_attr( $auto ); ?>">
		<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); ?>

			<?php
			$images = thim_meta( 'thim_gallery', "type=image&single=false&size=thumbnail" );
			$photos = sizeof( $images );

			$src = thim_aq_resize( get_the_post_thumbnail_url( get_the_ID() ), $result[0][0], $result[0][1], true );

			?>

            <div class="item">
                <a class="image" href="<?php echo esc_attr( get_permalink() ); ?>"
                   data-post="<?php echo esc_attr( get_the_ID() ); ?>" data-count="<?php echo esc_attr( $photos ); ?>">
                    <img src="<?php echo esc_attr( $src ); ?>">
                </a>
                <div class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
                <div class="count">
					<?php

					if ( $photos <= 1 ) {
						echo $photos . ' photo';
					} else {
						echo $photos . ' photos';
					}
					?>
                </div>
            </div>

		<?php endwhile;
			wp_reset_postdata();
		endif; ?>
    </div>
    <?php
}


