<?php
/**
 * Plugin Name: Hotel WP Shortcodes
 * Plugin URI: http://thimpress.com
 * Description: Hotel WP Shortcodes for Visual Composer
 * Author: ThimPress
 * Author URI: http://thimpress.com
 * Version: 1.1.6
 * Text Domain: hotelwp_shortcodes
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Thim_Plugin_Hotel_WP_Shortcodes' ) ) {

	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

	class Thim_Plugin_Hotel_WP_Shortcodes {

		/**
		 * @var null
		 *
		 * @since 1.0.0
		 */
		protected static $_instance = null;

		/**
		 * Return unique instance.
		 *
		 * @since 1.0.0
		 */
		static function instance() {
			if ( ! self::$_instance ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 * constructor.
		 *
		 * @since 1.0.0
		 */
		private function __construct() {
			define( 'THIM_SC_PATH', plugin_dir_path( __FILE__ ) );
			define( 'THIM_SC_URL', plugin_dir_url( __FILE__ ) );
			add_filter( 'user_contactmethods', array( $this, 'modify_contact_methods' ) );

			// Depend on Visual Composer
			if ( ! is_plugin_active( 'js_composer/js_composer.php' ) ) {
				return;
			}
			$this->init();
			$this->load_shortcodes();
			vc_add_shortcode_param( 'number', array( $this, 'param_number' ) );
		}

		/**
		 * Add field to user profile
		 *
		 * @param $user_contact_method
		 *
		 * @return mixed
		 */
		public function modify_contact_methods( $user_contact_method ) {

			//Add Facebook
			$user_contact_method['facebook'] = 'Facebook';
			// Add Twitter
			$user_contact_method['twitter'] = 'Twitter';
			// Add Twitter
			$user_contact_method['skype'] = 'Skype';
			//Add Facebook
			$user_contact_method['pinterest'] = 'Pinterest';

			return $user_contact_method;
		}

		/**
		 * Register shortcodes.
		 *
		 * @since 1.0.0
		 */
		public function load_shortcodes() {

			require_once( THIM_SC_PATH . 'categories-link/categories-link.php' );
			require_once( THIM_SC_PATH . 'heading/heading.php' );

			if ( is_plugin_active( 'tp-event/tp-event.php' ) || is_plugin_active( 'wp-events-manager/wp-events-manager.php' ) ) {
				require_once( THIM_SC_PATH . 'list-events/list-events.php' );
			}

			require_once( THIM_SC_PATH . 'posts/posts.php' );
			require_once( THIM_SC_PATH . 'testimonials/testimonials.php' );
			require_once( THIM_SC_PATH . 'filter-gallery/filter-gallery.php' );
			require_once( THIM_SC_PATH . 'google-map/google-map.php' );
			require_once( THIM_SC_PATH . 'social-link/social-link.php' );
			require_once( THIM_SC_PATH . 'counter-box/counter-box.php' );
			require_once( THIM_SC_PATH . 'our-gallery/our-gallery.php' );
			require_once( THIM_SC_PATH . 'weather/weather.php' );
			require_once( THIM_SC_PATH . 'video/video.php' );
			require_once( THIM_SC_PATH . 'list-icon-box/list-icon-box.php' );

			if ( is_plugin_active( 'wp-hotel-booking/wp-hotel-booking.php' ) || is_plugin_active( 'tp-hotel-booking/tp-hotel-booking.php' ) ) {
				require_once( THIM_SC_PATH . 'hb-rooms/hb-rooms.php' );
				require_once( THIM_SC_PATH . 'hb-rooms-search/hb-rooms-search.php' );
			}

		}

		/**
		 * Load functions.
		 *
		 * @since 1.0.0
		 */
		public function init() {
			require_once( THIM_SC_PATH . 'functions.php' );
		}

		/**
		 * Create custom param number
		 *
		 * @param $settings
		 * @param $value
		 *
		 * @since 1.0.0
		 * @return string
		 */
		public function param_number( $settings, $value ) {
			$param_name = isset( $settings['param_name'] ) ? $settings['param_name'] : '';
			$type       = isset( $settings['type'] ) ? $settings['type'] : '';
			$min        = isset( $settings['min'] ) ? $settings['min'] : '';
			$max        = isset( $settings['max'] ) ? $settings['max'] : '';
			$suffix     = isset( $settings['suffix'] ) ? $settings['suffix'] : '';
			$class      = isset( $settings['class'] ) ? $settings['class'] : '';
			$output     = '<input type="number" min="' . $min . '" max="' . $max . '" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="' . $value . '" style="max-width:100px; margin-right: 10px;" />' . $suffix;

			return $output;
		}
	}

	Thim_Plugin_Hotel_WP_Shortcodes::instance();
}