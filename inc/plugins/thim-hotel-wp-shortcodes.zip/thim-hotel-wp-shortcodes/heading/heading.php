<?php
/**
 * Heading shortcode
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Mapping shortcode Heading
vc_map( array(
	'name'        => esc_html__( 'Thim Heading', 'hotel-wp' ),
	'base'        => 'thim-heading',
	'category'    => esc_html__( 'Thim Shortcodes', 'hotel-wp' ),
	'description' => esc_html__( 'Display heading.', 'hotel-wp' ),
	'params'      => array(
		//Heading Primary
		array(
			'type'        => 'textfield',
			'admin_label' => true,
			'heading'     => esc_html__( 'HEADING PRIMARY', 'hotel-wp' ),
			'param_name'  => 'heading_primary',
			'value'       => esc_html__( 'Hello', 'hotel-wp' ),
			'description' => esc_html__( 'Write the title for the heading.', 'hotel-wp' )
		),
		//Use custom or default title?
		array(
			'type'        => 'dropdown',
			'admin_label' => true,
			'heading'     => esc_html__( 'Use custom or default heading primary?', 'hotel-wp' ),
			'param_name'  => 'primary_custom',
			'value'       => array(
				esc_html__( 'Default', 'hotel-wp' ) => '',
				esc_html__( 'Custom', 'hotel-wp' )  => 'custom',
			),
			'description' => esc_html__( 'If you select default you will use default title which customized in typography.', 'hotel-wp' )
		),

		//Title color
		array(
			'type'        => 'colorpicker',
			'admin_label' => true,
			'heading'     => esc_html__( 'Heading primary color ', 'hotel-wp' ),
			'param_name'  => 'primary_color',
			'value'       => '#E7AD44',
			'description' => esc_html__( 'Select the heading primary color.', 'hotel-wp' ),
			'dependency'  => array(
				'element' => 'primary_custom',
				'value'   => 'custom',
			),
		),
		//Title size
		array(
			'type'        => 'number',
			'admin_label' => true,
			'heading'     => esc_html__( 'Heading primary size ', 'hotel-wp' ),
			'param_name'  => 'primary_size',
			'min'         => 0,
			'value'       => '18',
			'suffix'      => 'px',
			'description' => esc_html__( 'Select the heading primary size.', 'hotel-wp' ),
			'dependency'  => array(
				'element' => 'primary_custom',
				'value'   => 'custom',
			),
		),
		//Title weight
		array(
			'type'        => 'dropdown',
			'admin_label' => true,
			'heading'     => esc_html__( 'Heading primary weight ', 'hotel-wp' ),
			'param_name'  => 'primary_weight',
			'value'       => array(
				esc_html__( 'Choose the title font weight', 'hotel-wp' ) => '',
				esc_html__( 'Normal', 'hotel-wp' )                       => 'normal',
				esc_html__( 'Bold', 'hotel-wp' )                         => 'bold',
				esc_html__( 'Bolder', 'hotel-wp' )                       => 'bolder',
				esc_html__( 'Lighter', 'hotel-wp' )                      => 'lighter',
			),
			'description' => esc_html__( 'Select the heading primary weight.', 'hotel-wp' ),
			'dependency'  => array(
				'element' => 'primary_custom',
				'value'   => 'custom',
			),
		),
		//Title style
		array(
			'type'        => 'dropdown',
			'admin_label' => true,
			'heading'     => esc_html__( 'Heading primary style ', 'hotel-wp' ),
			'param_name'  => 'primary_style',
			'value'       => array(
				esc_html__( 'Choose the title font style', 'hotel-wp' ) => '',
				esc_html__( 'Italic', 'hotel-wp' )                      => 'italic',
				esc_html__( 'Oblique', 'hotel-wp' )                     => 'oblique',
				esc_html__( 'Initial', 'hotel-wp' )                     => 'initial',
				esc_html__( 'Inherit', 'hotel-wp' )                     => 'inherit',
			),
			'description' => esc_html__( 'Select the heading primary style.', 'hotel-wp' ),
			'dependency'  => array(
				'element' => 'primary_custom',
				'value'   => 'custom',
			),
		),
		//Display line?
		array(
			'type'        => 'checkbox',
			'admin_label' => true,
			'heading'     => esc_html__( 'Hide line?', 'hotel-wp' ),
			'param_name'  => 'hide_line',
			'description' => esc_html__( 'Tick it to hide line in heading primary.', 'hotel-wp' ),
			'dependency'  => array(
				'element' => 'primary_custom',
				'value'   => 'custom',
			),
		),

		//Heading Seccondary
		array(
			'type'        => 'textfield',
			'admin_label' => true,
			'heading'     => esc_html__( 'HEADING SECONDARY', 'hotel-wp' ),
			'value'		  => esc_html__( 'WORLD', 'hotel-wp' ),
			'param_name'  => 'heading_secondary',
			'description' => esc_html__( 'Write the title for the heading secondary.', 'hotel-wp' )
		),

		//Use custom or default title?
		array(
			'type'        => 'dropdown',
			'admin_label' => true,
			'heading'     => esc_html__( 'Use custom or default heading secondary?', 'hotel-wp' ),
			'param_name'  => 'secondary_custom',
			'value'       => array(
				esc_html__( 'Default', 'hotel-wp' ) => '',
				esc_html__( 'Custom', 'hotel-wp' )  => 'custom',
			),
			'description' => esc_html__( 'If you select default you will use default title which customized in typography.', 'hotel-wp' )
		),

		//Heading secondary tag
		array(
			'type'        => 'dropdown',
			'admin_label' => true,
			'heading'     => esc_html__( 'Heading secondary tag', 'hotel-wp' ),
			'param_name'  => 'secondary_tag',
			'value'       => array(
				'h2' => 'h2',
				'h3' => 'h3',
				'h4' => 'h4',
				'h5' => 'h5',
				'h6' => 'h6',
			),
			'description' => esc_html__( 'Choose heading element.', 'hotel-wp' ),
			'dependency'  => array(
				'element' => 'secondary_custom',
				'value'   => 'custom',
			),
		),
		// Heading secondary color
		array(
			'type'        => 'colorpicker',
			'admin_label' => true,
			'heading'     => esc_html__( 'Heading secondary color ', 'hotel-wp' ),
			'param_name'  => 'secondary_color',
			'value'       => '#E7AD44',
			'description' => esc_html__( 'Select the heading secondary color.', 'hotel-wp' ),
			'dependency'  => array(
				'element' => 'secondary_custom',
				'value'   => 'custom',
			),
		),
		// Heading secondary size
		array(
			'type'        => 'number',
			'admin_label' => true,
			'heading'     => esc_html__( 'Heading secondary size ', 'hotel-wp' ),
			'param_name'  => 'secondary_size',
			'min'         => 0,
			'value'       => '36',
			'suffix'      => 'px',
			'description' => esc_html__( 'Select the heading secondary size.', 'hotel-wp' ),
			'dependency'  => array(
				'element' => 'secondary_custom',
				'value'   => 'custom',
			),
		),

		//Title style
		array(
			'type'        => 'dropdown',
			'admin_label' => true,
			'heading'     => esc_html__( 'Heading secondary style ', 'hotel-wp' ),
			'param_name'  => 'secondary_style',
			'value'       => array(
				esc_html__( 'Choose the title font style', 'hotel-wp' ) => '',
				esc_html__( 'Italic', 'hotel-wp' )                      => 'italic',
				esc_html__( 'Oblique', 'hotel-wp' )                     => 'oblique',
				esc_html__( 'Initial', 'hotel-wp' )                     => 'initial',
				esc_html__( 'Inherit', 'hotel-wp' )                     => 'inherit',
			),
			'description' => esc_html__( 'Select the heading secondary style.', 'hotel-wp' ),
			'dependency'  => array(
				'element' => 'secondary_custom',
				'value'   => 'custom',
			),
		),



		// Description
		array(
			'type'        => 'textarea',
			'admin_label' => true,
			'heading'     => esc_html__( 'DESCRIPTION', 'hotel-wp' ),
			'param_name'  => 'description',
			'description' => esc_html__( 'Provide the description for this icon box.', 'hotel-wp' )
		),
		

		

		// If select display button, you can change your button link
		array(
			'type'        => 'textfield',
			'admin_label' => true,
			'heading'     => esc_html__( 'BUTTON LINK', 'hotel-wp' ),
			'param_name'  => 'button_text_link',
			'description' => esc_html__( 'Write text link for the button.', 'hotel-wp' )
		),

		// If select display button, you can change your button text
		array(
			'type'        => 'textfield',
			'admin_label' => true,
			'heading'     => esc_html__( 'Button text', 'hotel-wp' ),
			'param_name'  => 'button_text',
			'description' => esc_html__( 'Write text for the button.', 'hotel-wp' )
		),

		//Alignment
		array(
			'type'        => 'dropdown',
			'admin_label' => true,
			'heading'     => esc_html__( 'Shortcode alignment', 'hotel-wp' ),
			'param_name'  => 'alignment',
			'value'       => array(
				'Choose the text alignment'         => '',
				esc_html__( 'Shortcode at left', 'hotel-wp' )   => 'left',
				esc_html__( 'Shortcode at center', 'hotel-wp' ) => 'center',
				esc_html__( 'Shortcode at right', 'hotel-wp' )  => 'right',
			),
		),
		//Animation
		array(
			"type"        => "dropdown",
			"heading"     => esc_html__( "Animation", "hotel-wp" ),
			"param_name"  => "css_animation",
			"admin_label" => true,
			"value"       => array(
				esc_html__( "No", "hotel-wp" )                 => '',
				esc_html__( "Top to bottom", "hotel-wp" )      => "top-to-bottom",
				esc_html__( "Bottom to top", "hotel-wp" )      => "bottom-to-top",
				esc_html__( "Left to right", "hotel-wp" )      => "left-to-right",
				esc_html__( "Right to left", "hotel-wp" )      => "right-to-left",
				esc_html__( "Appear from center", "hotel-wp" ) => "appear"
			),
			"description" => esc_html__( "Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", "hotel-wp" )
		),
		// Extra class
		array(
			'type'        => 'textfield',
			'admin_label' => true,
			'heading'     => esc_html__( 'Extra class', 'hotel-wp' ),
			'param_name'  => 'el_class',
			'value'       => '',
			'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'hotel-wp' ),
		),
	)
) );




/**
 * Template
 */
include_once 'tpl/default.php';