<?php
/**
 * Shortcode Heading
 *
 * @param $atts
 *
 * @return string
 */
function thim_shortcode_heading( $atts ) {
	$heading = shortcode_atts( array(
		'heading_primary'   => '',
		'primary_custom'	=> '',
		'primary_color' 	=> '',
		'primary_size' 		=> '',
		'primary_weight' 	=> '',
		'primary_style' 	=> '',
		'hide_line' 		=> '',
		
		'heading_secondary' => '',
		'secondary_custom'  => '',
		'secondary_tag' 	=> 'h3',
		'secondary_color' 	=> '',
		'secondary_size' 	=> '',
		'secondary_style' 	=> '',

		'description' 		=> '',

		'button_text_link'  => '',
		'button_text'       => '',

		'css_animation'     => '',
		'el_class'          => '',
		'alignment'         => '',
	), $atts );

	$css_animation = thim_getCSSAnimation( $heading['css_animation'] );

	$alignment = '';
	if ( $heading['alignment'] ) {
		$alignment = 'style = text-align:' . $heading['alignment'] . '; ';
	}
	
	// Heading primary inline style
	$primary_css = '';
	if ($heading['primary_color']) {
		$primary_css .= 'color: '. $heading['primary_color'] .';';
	}
	if ($heading['primary_size']) {
		$primary_css .= 'font-size: '. $heading['primary_size'] .'px;';
	}
	if ($heading['primary_weight']) {
		$primary_css .= 'font-weight: '. $heading['primary_weight'] .';';
	}
	if ($heading['primary_style']) {
		$primary_css .= 'font-style: '. $heading['primary_style'] .';';
	}
	if ( $primary_css ) {
		$primary_css = 'style="'. $primary_css .'"';
	}

	// Heading secondary inline style
	$secondary_css = '';
	if ($heading['secondary_color']) {
		$secondary_css .= 'color: '. $heading['secondary_color'] .';';
	}
	if ($heading['secondary_size']) {
		$secondary_css .= 'font-size: '. $heading['secondary_size'] .'px;';
	}
	if ($heading['secondary_style']) {
		$secondary_css .= 'font-style: '. $heading['secondary_style'] .';';
	}
	if ( $secondary_css ) {
		$secondary_css = 'style="'. $secondary_css .'"';
	}

	// Turn off line
	if ( $heading['hide_line'] == true ) {
		$line = 'no-line';
	} else { $line = ''; }

	// Description
	$descripton = '';
	if ( $heading['description'] ) {
		$descripton .= '<div class="heading-des">' . $heading['description'] . '</div>';
	}

	// Button
	$button = '';
	if ( $heading['button_text'] <> '' && $heading['button_text_link'] <> '' ) {
		$button .= '<div class="heading-button"><a href="' . esc_url($heading['button_text_link']) . '"><i class="icomoon icon-up"></i>' . esc_attr( $heading['button_text'] ) . '</a></div>';
	}
	// Heading secondary
	$heading_secondary = '';
	if ( $heading['heading_secondary'] <> '' ) {
		$heading_secondary .= '<'. $heading['secondary_tag'] .' '. ent2ncr($secondary_css) .' class="heading_secondary">' . $heading['heading_secondary'] . '</'. $heading['secondary_tag'] .'>';
	}
	$heading_primary = '';
	if ( $heading['heading_primary'] <> '' ) {
		$heading_primary .= '<p class="heading_primary" ' . ent2ncr( $primary_css ) . ' >' . $heading['heading_primary'] . '</p>';
	}

	$html = '
	<div class="thim-sc-heading ' . ent2ncr( $css_animation ) . ' ' . esc_attr( $heading['el_class'] ) . '" ' . $alignment . '>
		<div class="article_heading '. esc_attr( $line ) .'">
			'.$heading_primary.'
			'. $heading_secondary .'
			'. $descripton .' 
			'. $button .'
		</div>
	</div>';

	return ent2ncr($html);
}

add_shortcode( 'thim-heading', 'thim_shortcode_heading' );