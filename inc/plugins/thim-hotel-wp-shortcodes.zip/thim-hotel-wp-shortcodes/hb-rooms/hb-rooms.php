<?php
/**
 * Shortcode HB Rooms
 */

vc_map(
    array(
        'name'        => esc_html__( 'Thim HB Rooms', 'hotel-wp' ),
        'base'        => 'thim-hb-rooms',
        'class'       => '',
        'category'    => esc_html__( 'Thim Shortcodes', 'hotel-wp' ),
        'description' => esc_html__( 'Display HB Rooms.', 'hotel-wp' ),
        'params'      => array(

            // Number rooms
            array(
                'type'        => 'number',
                'admin_label' => true,
                'heading'     => esc_html__( 'Number Rooms', 'hotel-wp' ),
                'param_name'  => 'number_rooms',
                'min'         => 1,
                'max'         => 4,
                'value'       => 3,
                'description' => esc_html__( 'Number rooms display.', 'hotel-wp' ),
            ),

            // Link Text
            array(
                'type'        => 'textfield',
                'admin_label' => true,
                'heading'     => esc_html__( 'Link Text', 'hotel-wp' ),
                'value'		  => esc_html__( 'View all', 'hotel-wp' ),
                'param_name'  => 'link_text',
                'description' => esc_html__( 'Write the title for the button link.', 'hotel-wp' )
            ),

            //Animation
            array(
                "type"        => "dropdown",
                "heading"     => esc_attr__( "Animation", 'hotel-wp' ),
                "param_name"  => "css_animation",
                "admin_label" => true,
                "value"       => array(
                    esc_attr__( "No", 'hotel-wp' )                 => '',
                    esc_attr__( "Top to bottom", 'hotel-wp' )      => "top-to-bottom",
                    esc_attr__( "Bottom to top", 'hotel-wp' )      => "bottom-to-top",
                    esc_attr__( "Left to right", 'hotel-wp' )      => "left-to-right",
                    esc_attr__( "Right to left", 'hotel-wp' )      => "right-to-left",
                    esc_attr__( "Appear from center", 'hotel-wp' ) => "appear"
                ),
                "description" => esc_attr__( "Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'hotel-wp' )
            ),

            // Extra class
            array(
                'type'        => 'textfield',
                'admin_label' => true,
                'heading'     => esc_attr__( 'Extra class', 'hotel-wp' ),
                'param_name'  => 'el_class',
                'value'       => '',
                'description' => esc_attr__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'hotel-wp' ),
            ),
        )
    )
);

/**
 * include template
 */
include_once 'tpl/default.php';