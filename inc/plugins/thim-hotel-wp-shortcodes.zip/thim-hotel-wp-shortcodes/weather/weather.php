<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Thim_SC_Weather' ) ) {

	class Thim_SC_Weather {

		/**
		 * Shortcode name
		 * @var string
		 */
		protected $name = '';

		/**
		 * Shortcode description
		 * @var string
		 */
		protected $description = '';

		/**
		 * Shortcode base
		 * @var string
		 */
		protected $base = '';


		public function __construct() {

			//======================== CONFIG ========================
			$this->name        = esc_attr__( 'Thim Weather', 'hotel-wp' );
			$this->description = esc_attr__( 'Display Weather', 'hotel-wp' );
			$this->base        = 'weather';
			//====================== END: CONFIG =====================


			$this->map();
			add_shortcode( 'thim-' . $this->base, array( $this, 'shortcode' ) );
		}

		/**
		 * vc map shortcode
		 */
		public function map() {
			vc_map( array(
					'name'        => $this->name,
					'base'        => 'thim-' . $this->base,
					'category'    => esc_attr__( 'Thim Shortcodes', 'hotel-wp' ),
					'description' => $this->description,
					'params'      => array(
						array(
							"type"        => "textfield",
							"admin_label" => true,
							"heading"     => esc_attr__( "Location", 'hotel-wp' ),
							"param_name"  => "location",
							'value'       => 'London',
							"description" => esc_html__( "Write the your location.", "hotel-wp" )
						),
						array(
							"type"        => "dropdown",
							"heading"     => esc_html__( "Unit", "hotel-wp" ),
							"param_name"  => "unit",
							"admin_label" => true,
							"value"       => array(
								esc_html__( "C", "hotel-wp" )  => "c",
								esc_html__( "F", "hotel-wp" )  => "f",
							),
							"description" => esc_html__( "Select unit of weather", "hotel-wp" )
						),
					)
				)
			);
		}

		/**
		 * Add shortcode
		 *
		 * @param $atts
		 */
		public function shortcode( $atts ) {

			$params = shortcode_atts( array(
				'location'  => 'London',
				'unit'		=> 'c',
			), $atts );
			ob_start();

			include_once THIM_SC_PATH . 'weather/tpl/default.php';

			$html = ob_get_contents();
			ob_end_clean();
			return $html;

		}

	}

	new Thim_SC_Weather();
}
