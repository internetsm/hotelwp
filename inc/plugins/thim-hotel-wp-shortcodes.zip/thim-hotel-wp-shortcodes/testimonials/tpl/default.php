<?php

$css_animation = esc_attr( $params['css_animation'] );
$style         = esc_attr( $params['style'] );
$el_class      = esc_attr( $params['el_class'] );
$title         = $params['title'];
$auto          = $params['auto'];

?>

	<div class="thim-sc-testimonial <?php echo $style . ' ' . $el_class; ?>" data-animation="<?php echo $css_animation; ?>" data-auto="<?php echo $auto; ?>">
		<h4 class="block-title"><?php echo $title; ?></h4>
		<?php if ( $testimonials_qurey->have_posts() ) : ?>
			<div class="owl-carousel owl-theme testimonial-slider-<?php echo $style; ?>">
				<?php while ( $testimonials_qurey->have_posts() ) : $testimonials_qurey->the_post(); ?>
					<div class="testimonial-item">
						<div class="testimonial-content"><?php echo get_the_content(); ?></div>
						<p class="testimonial-rating"></p>
						<h5 class="testimonial-name"><?php the_title( ' ', ' ' ); ?></h5>
					</div>
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
			</div>
		<?php endif; ?>
	</div>

<?php

