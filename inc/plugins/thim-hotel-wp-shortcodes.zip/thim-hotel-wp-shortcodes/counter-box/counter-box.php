<?php
/**
 * Heading shortcode
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * include template
 */
include_once 'tpl/default.php';

vc_map(
	array(
		'name'        => esc_html__( 'Thim Counter Box', 'hotel-wp' ),
		'base'        => 'thim-counter-box',
		'class'       => '',
		'category'    => esc_html__( 'Thim Shortcodes', 'hotel-wp' ),
		'description' => esc_html__( 'Display counter box.', 'hotel-wp' ),
		'params'      => array(

			// params group
			array(
				'type'       => 'param_group',
				'value'      => '',
				'param_name' => 'counter_list',
				// Note params is mapped inside param-group:
				'params'     => array(
					// Number
					array(
						'type'        => 'number',
						'admin_label' => true,
						'value'       => 10,
						'min'         => 0,
						'heading'     => esc_html__( 'Number', 'hotel-wp' ),
						'param_name'  => 'number',
						'description' => esc_html__( 'Enter number in box to count.', 'hotel-wp' ),
					),
					// Label
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Label', 'hotel-wp' ),
						'admin_label' => true,
						'param_name'  => 'label',
						'value'       => '',
						'description' => esc_html__( 'Label counter box.', 'hotel-wp' ),
					),
				)
			),
		)
	)
);