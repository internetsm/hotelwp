<?php
/**
 * Shortcode list post
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * include template
 */
include_once 'tpl/default.php';

/**
 * Mapping shortcode
 */
vc_map(array(
    'name' => esc_attr__('Thim Posts', 'hotel-wp'),
    'base' => 'thim-posts',
    'category' => esc_attr__('Thim Shortcodes', 'hotel-wp'),
    'description' => esc_attr__('Display posts', 'hotel-wp'),
    'params' => array(
        // Posts number
        array(
            "type" => "number",
            "heading" => esc_attr__("Number posts", 'hotel-wp'),
            "param_name" => "post_limit",
            "admin_label" => true,
            'value' => 3,
            'description' => esc_attr__('Number posts to display.', 'hotel-wp'),
        ),
        // Columns
        array(
            "type" => "number",
            "heading" => esc_attr__("Columns", 'hotel-wp'),
            "param_name" => "post_column",
            "admin_label" => true,
            'value' => 3,
            'description' => esc_attr__('Number columns', 'hotel-wp'),
            'dependency' => array(
                'element' => 'style',
                'value' => array(
                    'style-1',
                    'style-2'
                ),
            ),
        ),
        // Display button?
        array(
            'type' => 'checkbox',
            'admin_label' => true,
            'heading' => esc_html__('Hide button Read more?', 'hotel-wp'),
            'param_name' => 'post_button',
            'description' => esc_html__('Tick it to hide the button read more.', 'hotel-wp'),
        ),
        //Use custom or default title?
        array(
            'type' => 'dropdown',
            'admin_label' => true,
            'heading' => esc_html__('Use custom or default readmore button?', 'hotel-wp'),
            'param_name' => 'readmore_custom',
            'value' => array(
                esc_html__('Default', 'hotel-wp') => '',
                esc_html__('Custom', 'hotel-wp') => 'custom',
            ),
        ),
        //Readmore Text
        array(
            'type' => 'textfield',
            'admin_label' => true,
            'heading' => esc_html__('Text Readmore', 'hotel-wp'),
            'param_name' => 'readmore_text',
            'value' => esc_html__('Read More', 'hotel-wp'),
            'description' => esc_html__('Write the text for readmore button.', 'hotel-wp'),
            'dependency' => array(
                'element' => 'readmore_custom',
                'value' => 'custom',
            ),
        ),
        //Readmore color
        array(
            'type' => 'colorpicker',
            'admin_label' => true,
            'heading' => esc_html__('Readmore color ', 'hotel-wp'),
            'param_name' => 'readmore_color',
            'value' => '#e7ad44',
            'description' => esc_html__('Select the readmore button color.', 'hotel-wp'),
            'dependency' => array(
                'element' => 'readmore_custom',
                'value' => 'custom',
            ),
        ),
       // Select category
        array(
            'type' => 'dropdown',
            'admin_label' => true,
            'heading' => esc_html__('Select category', 'construction-wp'),
            'param_name' => 'cat_id',
            'value' => thim_get_post_categories()
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_attr__("Style", 'hotel-wp'),
            "param_name" => "style",
            "admin_label" => true,
            "value" => array(
                esc_attr__('Style 1', 'hotel-wp') => 'style-1',
                esc_attr__('Style 2', 'hotel-wp') => 'style-2',
                esc_attr__('Style 3', 'hotel-wp') => 'style-3',
            ),
            "description" => esc_attr__("Select layout style.", 'hotel-wp')
        ),
        // Display category?
        array(
            'type' => 'checkbox',
            'admin_label' => true,
            'heading' => esc_html__('Show category', 'hotel-wp'),
            'param_name' => 'category_button',
            'description' => esc_html__('Tick it to show category.', 'hotel-wp'),
            'edit_field_class' => 'vc_col-sm-4',
            'dependency' => array(
                'element' => 'style',
                'value' => array(
                    'style-3'
                ),
            ),
        ),
        //Background category
        array(
            'type' => 'colorpicker',
            'admin_label' => true,
            'heading' => esc_html__('Background Category color ', 'hotel-wp'),
            'param_name' => 'bg_category',
            'value' => '#009ae2',
            'description' => esc_html__('Select the Background Category color.', 'hotel-wp'),
            'dependency' => array(
                'element' => 'style',
                'value' => array(
                    'style-3'
                ),
            ),
        ),
        // Display info?
        array(
            'type' => 'checkbox',
            'admin_label' => true,
            'heading' => esc_html__('Show custom info post', 'hotel-wp'),
            'param_name' => 'info_button',
            'description' => esc_html__('Tick it to show custom info post.', 'hotel-wp'),
            'dependency' => array(
                'element' => 'style',
                'value' => array(
                    'style-2'
                ),
            ),
        ),
        // Display excerpt?
        array(
            'type' => 'checkbox',
            'admin_label' => true,
            'heading' => esc_html__('Show excerpt description', 'hotel-wp'),
            'param_name' => 'excerpt_button',
            'description' => esc_html__('Tick it to show excerpt description.', 'hotel-wp'),
            'dependency' => array(
                'element' => 'style',
                'value' => array(
                    'style-2',
                    'style-3'
                ),
            ),
        ),
        //Animation
        array(
            "type" => "dropdown",
            "heading" => esc_attr__("Animation", 'hotel-wp'),
            "param_name" => "css_animation",
            "admin_label" => true,
            "value" => array(
                esc_attr__("No", 'hotel-wp') => '',
                esc_attr__("Top to bottom", 'hotel-wp') => "top-to-bottom",
                esc_attr__("Bottom to top", 'hotel-wp') => "bottom-to-top",
                esc_attr__("Left to right", 'hotel-wp') => "left-to-right",
                esc_attr__("Right to left", 'hotel-wp') => "right-to-left",
                esc_attr__("Appear from center", 'hotel-wp') => "appear"
            ),
            "description" => esc_attr__("Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'hotel-wp')
        ),

        // Extra class
        array(
            'type' => 'textfield',
            'admin_label' => true,
            'heading' => esc_attr__('Extra class', 'hotel-wp'),
            'param_name' => 'el_class',
            'value' => '',
            'description' => esc_attr__('Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'hotel-wp'),
        ),
    )
));


/**
 * Template
 */
require_once 'tpl/default.php';