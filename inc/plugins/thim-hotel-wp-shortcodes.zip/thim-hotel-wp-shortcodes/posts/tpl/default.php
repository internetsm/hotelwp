<?php
/**
 * Created by PhpStorm.
 * User: khoapq
 * Date: 8/11/2016
 * Time: 8:38 AM
 */

/**
 * Shortcode Posts
 *
 * @param $atts
 *
 * @return string
 */

//Get list category
function thim_get_post_categories()
{
    global $wpdb;
    $query = $wpdb->get_results($wpdb->prepare(
        "
				  SELECT      t1.term_id, t2.name
				  FROM        $wpdb->term_taxonomy AS t1
				  INNER JOIN $wpdb->terms AS t2 ON t1.term_id = t2.term_id
				  WHERE t1.taxonomy = %s
				  AND t1.count > %d
				  ",
        'category', 0
    ));

    $cats = array();
    $cats[esc_html__('All', 'hotel-wp')] = 'all';
    if (!empty($query)) {
        foreach ($query as $value) {
            $cats[$value->name] = $value->term_id;
        }
    }

    return $cats;
}


add_shortcode('thim-posts', 'thim_shortcode_posts');
function thim_shortcode_posts($atts)
{
    $param_post = shortcode_atts(array(
        'post_limit' => 2,
        'post_column' => 2,
        'display' => '',
        'readmore_custom' => '',
        'readmore_text' => '',
        'readmore_color' => '',
        'style' => 'style-1',
        'category_button' => '',
        'bg_category' => '',
        'info_button' => '',
        'excerpt_button' => '',
        'css_animation' => '',
        'post_button' => '',
        'el_class' => '',
        'cat_id' => '',
    ), $atts);

    $button = $html = '';

    $css_animation = thim_getCSSAnimation($param_post['css_animation']);
    $class = 'col-sm-6 col-md-' . (12 / $param_post['post_column']);

    // Heading primary inline style
    $readmore_text = '';
    if ($param_post['readmore_text'] != '') {
        $readmore_text = $param_post['readmore_text'];
    } else {
        $readmore_text = esc_html__('Read More', 'hotel-wp');
    }
    $readmore_css = '';
    if ($param_post['readmore_color']) {
        $readmore_css .= 'color: ' . $param_post['readmore_color'] . ';';
    }
    if ($readmore_css) {
        $readmore_css = 'style="' . $readmore_css . '"';
    }

    // Backgroudn Color
    $category_css = '';
    if ($param_post['bg_category']) {
        $category_css .= 'background-color: ' . $param_post['bg_category'] . ';';
    }
    if ($category_css) {
        $category_css = 'style="' . $category_css . '"';
    }

    $posts_args = array(
        'posts_per_page' => $param_post['post_limit'],
        'ignore_sticky_posts' => 1,
        'cat' => $param_post['cat_id']
    );


    $posts = new WP_Query($posts_args);
    $i = 0;

    $html .= '<div class="thim-sc-posts site-content ' . $css_animation . ' ' . esc_attr($param_post['el_class']) . ' ">';
    $html .= '<div class="blog-content row">';
    if ($param_post['style'] == 'style-3') {
        if ($i == 0) {
            $html .= '<div class="item-first col-sm-12 col-md-6">';
        }
    }
    if ($posts->have_posts()) {
        while ($posts->have_posts()) :
            $posts->the_post();
            global $post;
            $thim_info = get_post_meta($post->ID, 'thim_info', true);

            //Set Class Style 3
            $i++;
            if ($param_post['style'] == 'style-3') {
                if ($i == 1) {
                    $class = 'col-sm-12 col-md-12 post-item-first';
                } else {
                    $class = 'col-sm-6 col-md-6 post-item';
                }
            }
            $html .= '<article id="post-' . get_the_ID() . '" class="' . $class . ' ' . $param_post['style'] . '">';
            $html .= '<div class="content-inner">';

            $html .= '<div class="entry-top">';

            $src = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
            $img_src = thim_aq_resize($src[0], 370, 300, true);
            if ($param_post['style'] == 'style-3') {
                if ($i == 1) {
                    $img_src = thim_aq_resize($src[0], 570, 462, true);
                }
            }
            if (!$img_src) {
                $img_src = $src[0];
            }
            if ($img_src) {
                $html .= '<div class="thumbnail"><a href="' . esc_url(get_permalink(get_the_ID())) . '">';
                $html .= '<img src="' . esc_attr($img_src) . '" alt="' . get_the_title() . '" title="' . get_the_title() . '"/>';
                $html .= '</a></div>';
            }
            $html .= ' </div> ';

            $html .= '<div class="entry-content"> ';
            if ($param_post['style'] == 'style-3') {
                if ($param_post['category_button'] == true) {
                    $categories_list = get_the_category_list(' - ');
                    $html .= '<div class="entry-category" ' . $category_css . '>';
                    $html .= $categories_list;
                    $html .= '</div>';
                }
            }
            if ($param_post['style'] == 'style-1') {
                $html .= '<div class="entry-meta">';
                $html .= thim_get_entry_meta_date();
                $html .= '</div>';
            }

            $html .= '<header class="entry-header"> ';
            $html .= '<h3 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark"> ' . get_the_title() . '</a></h3>';
            $html .= '</header>';
            if ($param_post['style'] == 'style-3') {
                $html .= '<div class="entry-meta">';
                $html .= '<span class="entry-date">' . get_the_date('j M, Y') . '</span>';
                $html .= '</div>';
            }
            if ($param_post['style'] == 'style-2') {
                if ($param_post['info_button'] == true) {
                    if ($thim_info) {
                        $html .= '<div class="entry-info" > ';
                        $html .= $thim_info;
                        $html .= '</div>';
                    }
                }
            }

            if ($param_post['style'] == 'style-2' || $param_post['style'] == 'style-3') {
                if ($param_post['excerpt_button'] == true) {
                    $html .= '<div class="entry-summary" > ';
                    $html .= esc_attr(get_the_excerpt());
                    $html .= '</div>';
                }
            }

            if ($param_post['post_button'] == false) {
                $html .= '<div class="readmore' . esc_attr($button) . '" > ';
                $html .= '<a href = "' . esc_url(get_permalink()) . '" ' . $readmore_css . ' ><i class="icomoon icon-up"></i> ' . $readmore_text . ' </a> ';
                $html .= '</div>';
            }

            $html .= '</div> ';

            $html .= '</div> ';
            $html .= '</article> ';
            if ($param_post['style'] == 'style-3') {
                if ($i == 1) {
                    $html .= '</div>';
                    $html .= '<div class="item col-sm-12 col-md-6">';
                }
            }
        endwhile;
    }
    if ($param_post['style'] == 'style-3') {
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '</div>';
    wp_reset_postdata();

    return ent2ncr($html);
}

