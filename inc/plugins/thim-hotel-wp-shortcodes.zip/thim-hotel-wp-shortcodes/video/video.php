<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Thim_SC_Video' ) ) {

	class Thim_SC_Video {

		/**
		 * Shortcode name
		 * @var string
		 */
		protected $name = '';

		/**
		 * Shortcode description
		 * @var string
		 */
		protected $description = '';

		/**
		 * Shortcode base
		 * @var string
		 */
		protected $base = '';


		public function __construct() {

			//======================== CONFIG ========================
			$this->name        = esc_attr__( 'Thim Video', 'hotel-wp' );
			$this->description = esc_attr__( 'Display video', 'hotel-wp' );
			$this->base        = 'video';
			//====================== END: CONFIG =====================


			$this->map();
			add_shortcode( 'thim-' . $this->base, array( $this, 'shortcode' ) );
		}

		/**
		 * vc map shortcode
		 */
		public function map() {
			vc_map( array(
					'name'        => $this->name,
					'base'        => 'thim-' . $this->base,
					'category'    => esc_attr__( 'Thim Shortcodes', 'hotel-wp' ),
					'description' => $this->description,
					'params'      => array(
						array(
							"type"        => "textfield",
							"admin_label" => true,
							"heading"     => esc_attr__( "Title", 'hotel-wp' ),
							"param_name"  => "title",
							"description" => esc_html__( "Write the title for video.", "hotel-wp" )
						),
						array(
							"type"        => "textfield",
							"admin_label" => true,
							"heading"     => esc_attr__( "Text Icon", 'hotel-wp' ),
							"param_name"  => "text_icon",
							"description" => esc_html__( "Write the text for icon.", "hotel-wp" )
						),
						// Get Video
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'URL Video', 'hotel-wp' ),
							'param_name'  => 'video',
							'admin_label' => true,
							'value'       => '',
							'description' => esc_html__( 'Select an uploaded video in mp4 format. Other formats, such as webm and ogv will work in some browsers. You can use an online service such as <a href=\'http://video.online-convert.com/convert-to-mp4\' target=\'_blank\'>online-convert.com</a> to convert your videos to mp4.', 'hotel-wp' ),
						),
						// Get Cover Image
						array(
							'type'        => 'attach_images',
							'heading'     => esc_html__( 'Select cover image', 'hotel-wp' ),
							'param_name'  => 'cover_image',
							'admin_label' => true,
							'value'       => '',
							'description' => esc_html__( 'Select an uploaded video in mp4 format. Other formats, such as webm and ogv will work in some browsers', 'hotel-wp' ),
						),
						// Get auto play
						array(
							"type"             => "dropdown",
							"heading"          => esc_attr__( "Auto Play", 'hotel-wp' ),
							"param_name"       => "auto_play",
							"admin_label"      => true,
							"value"            => array(
								esc_attr__( 'No', 'hotel-wp' )      => 'no',
								esc_attr__( 'Yes', 'hotel-wp' )      => 'yes',
							),
							'edit_field_class' => 'vc_col-sm-3',
						),
						// Get auto hidden
						array(
							"type"             => "dropdown",
							"heading"          => esc_attr__( "Auto Hidden", 'hotel-wp' ),
							"param_name"       => "auto_hidden",
							"admin_label"      => true,
							"value"            => array(
								esc_attr__( 'No', 'hotel-wp' )      => 'no',
								esc_attr__( 'Yes', 'hotel-wp' )      => 'yes',
							),
							'edit_field_class' => 'vc_col-sm-3',
						),
						// Get Muted
						array(
							"type"             => "dropdown",
							"heading"          => esc_attr__( "Muted", 'hotel-wp' ),
							"param_name"       => "muted",
							"admin_label"      => true,
							"value"            => array(
								esc_attr__( 'Yes', 'hotel-wp' )      => 'yes',
								esc_attr__( 'No', 'hotel-wp' )      => 'no',
							),
							'edit_field_class' => 'vc_col-sm-3',
						),
						// Get Loop
						array(
							"type"             => "dropdown",
							"heading"          => esc_attr__( "Loop", 'hotel-wp' ),
							"param_name"       => "loop",
							"admin_label"      => true,
							"value"            => array(
								esc_attr__( 'Yes', 'hotel-wp' )      => 'yes',
								esc_attr__( 'No', 'hotel-wp' )      => 'no',
							),
							'edit_field_class' => 'vc_col-sm-3',
						),
					)
				)
			);
		}

		/**
		 * Add shortcode
		 *
		 * @param $atts
		 */
		public function shortcode( $atts ) {

			$params = shortcode_atts( array(
				'title' => '',
				'text_icon'  => '',
				'video'		=> '',
				'cover_image' => '',
				'auto_play' => '',
				'auto_hidden' => '',
				'muted' => '',
				'loop' => '',
			), $atts );
			ob_start();

			include_once THIM_SC_PATH . 'video/tpl/default.php';

			$html = ob_get_contents();
			ob_end_clean();
			return $html;

		}

	}

	new Thim_SC_Video();
}
