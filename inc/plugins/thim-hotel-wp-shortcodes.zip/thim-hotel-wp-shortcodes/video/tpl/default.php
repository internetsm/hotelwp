<?php
$title = $params['title'];
$text_icon    = $params['text_icon'];
$video   	= 	$params['video'];
$cover_image   = wp_get_attachment_image_url( $params['cover_image'], 'full' );
$auto_hidden   = $params['auto_hidden'];

$auto_play = (isset($params['auto_play']) && $params['auto_play'] === 'false') ? 'false' : 'true';
$muted = (isset($params['muted']) && $params['muted'] === 'false') ? '' : 'muted';
$loop = (isset($params['loop']) && $params['loop'] === 'false') ? '' : 'loop';

?>
<div class="thim-sc-video">
	<div class="background-video">
		<div class="cover-image" style="background-image: url(<?php echo esc_url($cover_image); ?>)"></div>
		<div class="icons">
			<h3 class="title"><?php echo $title; ?></h3>
			<i class="video-play ion-ios-play"></i><span class="text-icon"><?php echo $text_icon; ?></span>
		</div>
		<video <?php echo esc_attr($loop); ?> <?php echo esc_attr($muted); ?> class="full-screen-video" data-autoplay="<?php echo esc_attr($muted); ?>">
			<source src="<?php echo esc_attr($video); ?>" type="video/mp4">
		</video>
	</div>
</div>