<?php
/**
 * Shortcode hb search rooms
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

vc_map(
    array(
        'name' => esc_html__('Thim HB Rooms Search', 'hotel-wp'),
        'base' => 'thim-hb-rooms-search',
        'class' => '',
        'category' => esc_html__('Thim Shortcodes', 'hotel-wp'),
        'description' => esc_html__('Display form rooms search.', 'hotel-wp'),
        'params' => array(
            // Layout style
            array(
                "type" => "dropdown",
                "heading" => esc_html__("Styles", "hotel-wp"),
                "param_name" => "style",
                "admin_label" => true,
                "value" => array(
                    esc_html__("Default", "hotel-wp") => '',
                    esc_html__("Box", "hotel-wp") => "box",
                    esc_html__("MultiDate", "hotel-wp") => 'special',
                ),
                "description" => esc_html__("Select type of styles.", "hotel-wp")
            ),

            //Background category
            array(
                'type' => 'textfield',
                'admin_label' => true,
                'heading' => esc_html__('Contact Info', 'hotel-wp'),
                'param_name' => 'contact_info',
                'description' => esc_html__('Add contact info of you.', 'hotel-wp'),
                'dependency' => array(
                    'element' => 'style',
                    'value' => array(
                        'special'
                    ),
                ),
            ),
            //Background category
            array(
                'type' => 'textfield',
                'admin_label' => true,
                'heading' => esc_html__('Language Room Search', 'hotel-wp'),
                'param_name' => 'lang_search',
                'description' => esc_html__('Language name short room search of you. Ex: eng-gb, it ...', 'hotel-wp'),
                'value' => 'en-gb',
                'dependency' => array(
                    'element' => 'style',
                    'value' => array(
                        'special'
                    ),
                ),
            ),

            //Animation
            array(
                "type" => "dropdown",
                "heading" => esc_attr__("Animation", 'hotel-wp'),
                "param_name" => "css_animation",
                "admin_label" => true,
                "value" => array(
                    esc_attr__("No", 'hotel-wp') => '',
                    esc_attr__("Top to bottom", 'hotel-wp') => "top-to-bottom",
                    esc_attr__("Bottom to top", 'hotel-wp') => "bottom-to-top",
                    esc_attr__("Left to right", 'hotel-wp') => "left-to-right",
                    esc_attr__("Right to left", 'hotel-wp') => "right-to-left",
                    esc_attr__("Appear from center", 'hotel-wp') => "appear"
                ),
                "description" => esc_attr__("Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'hotel-wp')
            ),

            // Extra class
            array(
                'type' => 'textfield',
                'admin_label' => true,
                'heading' => esc_attr__('Extra class', 'hotel-wp'),
                'param_name' => 'el_class',
                'value' => '',
                'description' => esc_attr__('Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'hotel-wp'),
            ),
        )
    )
);

/**
 * include template
 */
include_once 'tpl/default.php';