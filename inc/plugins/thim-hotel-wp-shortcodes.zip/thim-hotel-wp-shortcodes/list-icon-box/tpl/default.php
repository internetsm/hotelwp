<div class="thim-sc-list-icon-box">
    <div class="list-icon-box-wrapper <?php echo esc_attr($params['el_class']); ?>">
        <?php
        echo '<ul class="list-icon-box owl-carousel owl-theme">';
        foreach ($params['list_icon_box'] as $list_icon_box) {

            //Icon font type
            $icon_font = '';

            if ($list_icon_box['icon_type'] == 'fontawesome') {
                $icon_font = 'class = "' . $list_icon_box['icon_fontawesome'] . ' " ';
            } elseif ($list_icon_box['icon_type'] == 'openiconic') {
                $icon_font = 'class = "' . $list_icon_box['icon_openiconic'] . ' " ';
            } elseif ($list_icon_box['icon_type'] == 'typicons') {
                $icon_font = 'class = "' . $list_icon_box['icon_typicons'] . ' " ';
            } elseif ($list_icon_box['icon_type'] == 'entypo') {
                $icon_font = 'class = "' . $list_icon_box['icon_entypo'] . ' " ';
            } elseif ($list_icon_box['icon_type'] == 'linecons') {
                $icon_font = 'class = "' . $list_icon_box['icon_linecons'] . ' " ';
            } elseif ($list_icon_box['icon_type'] == 'ionicons') {
                $icon_font = 'class = "' . $list_icon_box['icon_ionicons'] . ' " ';
            }

            if ($list_icon_box['title']) {
                echo '<li class="box-item">';
                echo '<i ' . $icon_font . '></i>';
                echo '<h5 class="box-title">' . $list_icon_box['title'] . '</h5>';
                echo '<p class="description">' . $list_icon_box['description'] . '</p>';
                if ($list_icon_box['button_display'] == 'yes') {
                    echo '<a' . esc_url($list_icon_box['button_link']) . '>' . esc_attr($list_icon_box['button_value']) . '</a>';
                }
                echo '</li>';
            }
        }
        echo '</ul>';
        ?>
    </div>
</div>