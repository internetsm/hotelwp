<?php
/**
 * Shortcode List Events
 *
 * @param $atts
 *
 * @return string
 */

add_shortcode( 'thim-list-events', 'thim_shortcode_list_events' );

function thim_shortcode_list_events( $atts ) {
	$list_events = shortcode_atts( array(
		'number_events' => 3,
		'text_link'     => 3,
		'css_animation' => '',
		'el_class'      => '',
	), $atts );

	$css_animation = thim_getCSSAnimation( $list_events['css_animation'] );

	$number_events = $list_events['number_events'] ? $list_events['number_events'] : 3;
	$link          = get_post_type_archive_link( 'tp_event' );
	$query_args    = array(
		'post_type'           => 'tp_event',
		'posts_per_page'      => $number_events,
		'post_status'         => array( 'tp-event-happenning', 'tp-event-upcoming' ),
		'ignore_sticky_posts' => true
	);
	$events        = new WP_Query( $query_args );
	$html_result   = '';

	$html    = array();
	$sorting = array();

	$html_result .= '<div class="thim-sc-list-events ' . $css_animation . ' ' . esc_attr( $list_events['el_class'] ) . '">';
	if ( $events->have_posts() ) {
		$html_result .= '<div class="content-events">';
		while ( $events->have_posts() ) {
			$events->the_post();
			$class                                       = 'item-event';
			if ( class_exists( 'WPEMS' ) ) {
				$date_show = wpems_get_time('d');
				$month_show = wpems_get_time('M');
				$sorting[ strtotime( wpems_get_time() ) ] = get_the_ID();
			} else {
				$date_show = tp_event_get_time('d');
				$month_show = tp_event_get_time('M');
				$sorting[ strtotime( tp_event_get_time() ) ] = get_the_ID();
			}
			ob_start(); ?>
			<div <?php post_class( $class ); ?>>
				<div class="time-from">
					<?php do_action( 'thim_before_event_time' ); ?>
					<div class="date">
						<?php echo esc_html( $date_show ); ?>
					</div>
					<div class="month">
						<?php echo esc_html( $month_show ); ?>
					</div>
					<?php do_action( 'thim_after_event_time' ); ?>
				</div>
				<div class="event-wrapper">
					<h4 class="title">
						<a href="<?php echo esc_url( get_permalink( get_the_ID() ) ); ?>"> <?php echo get_the_title(); ?></a>
					</h4>
				</div>
			</div>

			<?php
			$html[ get_the_ID() ] = ob_get_contents();
			ob_end_clean();

		}

		ksort( $sorting );

		if ( ! empty( $sorting ) ) {
			$index = 1;
			foreach ( $sorting as $value ) {
				$html_result .= ent2ncr( $html[ $value ] );
				$index ++;
			}
		}
		$html_result .= '</div>';

		if ( $list_events['text_link'] != '' ) {
			$html_result .= '<a class="view-all" href="' . esc_url( $link ) . '"><i class="icomoon icon-up"></i>' . $list_events['text_link'] . '</a>';
		}

	}
	$html_result .= '</div>';

	wp_reset_postdata();

	return $html_result;
}

;