<?php
/**
 * Shortcode list events
 */
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

vc_map(
	array(
		'name'        => esc_attr__( 'Thim List Events', 'hotel-wp' ),
		'base'        => 'thim-list-events',
		'category'    => esc_attr__( 'Thim Shortcodes', 'hotel-wp' ),
		'description' => esc_attr__( 'Display List Event', 'hotel-wp' ),
		'params'      => array(
			// Events number
			array(
				"type"        => "number",
				"heading"     => esc_attr__( "Number events", 'hotel-wp' ),
				"param_name"  => "number_events",
				"admin_label" => true,
				'value'       => '',
				'description' => esc_attr__( 'Number events to display.', 'hotel-wp' ),
			),

			// Text link
			array(
				'type'        => 'textfield',
				'admin_label' => true,
				'heading'     => esc_attr__( 'Text link', 'hotel-wp' ),
				'param_name'  => 'text_link',
				'value'       => '',
				'description' => esc_attr__( 'Add text link to archive events.', 'hotel-wp' ),
			),

			//Animation
			array(
				"type"        => "dropdown",
				"heading"     => esc_attr__( "Animation", 'hotel-wp' ),
				"param_name"  => "css_animation",
				"admin_label" => true,
				"value"       => array(
					esc_attr__( "No", 'hotel-wp' )                 => '',
					esc_attr__( "Top to bottom", 'hotel-wp' )      => "top-to-bottom",
					esc_attr__( "Bottom to top", 'hotel-wp' )      => "bottom-to-top",
					esc_attr__( "Left to right", 'hotel-wp' )      => "left-to-right",
					esc_attr__( "Right to left", 'hotel-wp' )      => "right-to-left",
					esc_attr__( "Appear from center", 'hotel-wp' ) => "appear"
				),
				"description" => esc_attr__( "Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'hotel-wp' )
			),

			// Extra class
			array(
				'type'        => 'textfield',
				'admin_label' => true,
				'heading'     => esc_attr__( 'Extra class', 'hotel-wp' ),
				'param_name'  => 'el_class',
				'value'       => '',
				'description' => esc_attr__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'hotel-wp' ),
			),
		)
	)
);


/**
 * Template
 */
require_once THIM_SC_PATH . 'list-events/tpl/default.php';