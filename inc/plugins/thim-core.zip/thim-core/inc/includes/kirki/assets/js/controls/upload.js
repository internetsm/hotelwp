/**
 * Just clone from UploadControl of wp customize
 */
wp.customize.controlConstructor['kirki-upload'] = wp.customize.UploadControl;
