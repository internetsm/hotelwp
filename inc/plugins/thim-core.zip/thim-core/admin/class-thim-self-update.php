<?php

/**
 * Class Thim_Self_Update
 *
 * @since 1.0.4
 */
class Thim_Self_Update extends Thim_Singleton {
	/**
	 * @since 1.0.4
	 *
	 * @var string
	 */
	private $slug = 'thim-core';

	/**
	 * @since 1.0.4
	 *
	 * @var string
	 */
	private $plugin = 'thim-core/thim-core.php';

	/**
	 * @var string
	 *
	 * @since 1.0.4
	 */
	private $api_url = 'https://thimpresswp.github.io/thim-core/dist/update-check.json';

	/**
	 * Thim_Self_Update constructor.
	 *
	 * @since 1.0.4
	 */
	protected function __construct() {
		$this->init_hooks();
	}

	/**
	 * Init hooks.
	 *
	 * @since 1.0.4
	 */
	private function init_hooks() {
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update_plugins' ) );
		add_filter( 'pre_set_transient_update_plugins', array( $this, 'inject_update_plugins' ) );
		add_filter( 'http_request_args', array( $this, 'exclude_check_update_from_wp_org' ), 5, 2 );
	}

	/**
	 * Exclude check plugin update from wp.org.
	 *
	 * @since 1.0.4
	 *
	 * @param $request
	 * @param $url
	 *
	 * @return mixed
	 */
	public function exclude_check_update_from_wp_org( $request, $url ) {
		if ( false === strpos( $url, '//api.wordpress.org/plugins/update-check' ) ) {
			return $request;
		}

		$data   = json_decode( $request['body']['plugins'] );
		$plugin = $this->plugin;

		if ( isset( $data->plugins->$plugin ) ) {
			unset( $data->plugins->$plugin );
		}

		$request['body']['plugins'] = wp_json_encode( $data );

		return $request;
	}

	/**
	 * Get check update plugin thim core (from GitHub.io).
	 *
	 * @since 1.0.4
	 *
	 * @return array|bool
	 */
	private function get_data_check_update_plugin() {
		$response = wp_remote_get( $this->api_url );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$body   = wp_remote_retrieve_body( $response );
		$object = json_decode( $body );
		$arr    = (array) $object;

		return ! empty( $arr ) ? $arr : false;
	}

	/**
	 * Get information plugin thim core.
	 *
	 * @since 1.0.4
	 *
	 * @return array|bool
	 */
	private function get_plugin_information_remote() {
		$data = get_site_transient( '_thim_core_check_self_update' );

		if ( empty( $data ) ) {
			$data = $this->get_data_check_update_plugin();
			set_site_transient( '_thim_core_check_self_update', $data, 3600 );
		}

		return $data;
	}

	/**
	 * Get current version.
	 *
	 * @since 1.0.4
	 *
	 * @return string|bool
	 */
	private function get_current_version() {
		return defined( 'THIM_CORE_VERSION' ) ? THIM_CORE_VERSION : false;
	}

	/**
	 * Check can update.
	 *
	 * @since 1.0.4
	 *
	 * @param $current_version
	 * @param $latest_version
	 *
	 * @return bool
	 */
	private function can_update( $current_version, $latest_version ) {
		if ( ! $current_version || ! $latest_version ) {
			return false;
		}

		return version_compare( $latest_version, $current_version, '>' );
	}

	/**
	 * Add filter update plugins.
	 *
	 * @since 1.0.0
	 *
	 * @param $value
	 *
	 * @return mixed
	 */
	public function inject_update_plugins( $value ) {
		if ( ! $this->is_support() ) {
			return $value;
		}

		$data            = $this->get_plugin_information_remote();
		$latest_version  = ! empty( $data['version'] ) ? $data['version'] : false;
		$current_version = $this->get_current_version();
		if ( ! $this->can_update( $current_version, $latest_version ) ) {
			return $value;
		}

		$download_link = $data['download_link'];
		$url           = isset( $data['homepage'] ) ? $data['homepage'] : 'https://thimpresswp.github.io/thim-core/';

		$object              = new stdClass();
		$object->slug        = $this->slug;
		$object->plugin      = $this->plugin;
		$object->new_version = $latest_version;
		$object->url         = $url;
		$object->package     = $download_link;

		$value->response[ $this->plugin ] = $object;

		return $value;
	}

	/**
	 * Is support self update.
	 *
	 * @since 1.0.4
	 *
	 * @return mixed
	 */
	private function is_support() {
		return ( version_compare( THIM_CORE_VERSION, '1.0.3', '>' ) );
	}
}